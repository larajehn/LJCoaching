import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Link, NavLink, Route, Routes } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  BarChart3,
  BookOpen,
  Brain,
  Calendar,
  CheckCircle,
  Clock,
  GraduationCap,
  Layers,
  Lightbulb,
  MessageCircle,
  Monitor,
  Sparkles,
  Target,
  Menu,
  X
} from 'lucide-react';
import './styles.css';

const fields = {
  Medizin: {
    headline: 'Struktur für ein Studium, das sich nie fertig anfühlt.',
    problems: ['Zu viel Stoff', 'Ständiger Vergleich', 'Hoher Leistungsdruck', 'Angst, nicht genug zu wissen', 'Lernen ohne klares Ende', 'Emotionale Erschöpfung', 'Prüfungsdruck'],
    modules: ['Stoff priorisieren ohne Schuldgefühl', 'Lernpläne für grosse Stoffmengen', 'Prüfungsvorbereitung in Phasen', 'Umgang mit Vergleich und Selbstzweifel', 'Erholung als Lernstrategie'],
    tone: 'präzise, ruhig, leistungsbewusst, entlastend'
  },
  Psychologie: {
    headline: 'Klar denken, ohne dich ständig selbst zu analysieren.',
    problems: ['Zu viel Reflexion', 'Unsicherheit beim Berufsweg', 'Statistik Blockaden', 'Selbstzweifel trotz Interesse', 'Emotionale Überidentifikation', 'Entscheidungsdruck bei Master, Ausbildung oder Karriere'],
    modules: ['Studienweg klären', 'Statistik ohne Vermeidung', 'Reflexion begrenzen und nutzbar machen', 'Berufsentscheidungen strukturieren', 'Selbstzweifel in Daten übersetzen'],
    tone: 'differenziert, achtsam, analytisch, bodenständig'
  },
  Recht: {
    headline: 'Vom gedanklichen Chaos zur klaren Fallstruktur.',
    problems: ['Gutachtenstil', 'Angst vor Wissenslücken', 'Zu spätes Wiederholen', 'Grosse Textmengen', 'Perfektionismus', 'Blackouts in Klausuren', 'Fehlende Fallroutine'],
    modules: ['Falllösungen systematisch aufbauen', 'Stoff in Klausurstrukturen übersetzen', 'Wiederholungssysteme', 'Prüfungsvorbereitung ohne Panik', 'Perfektionismus reduzieren'],
    tone: 'klar, strukturiert, präzise, prüfungsnah'
  },
  'Wirtschaft': {
    headline: 'Prioritäten sehen, Entscheidungen treffen, ins Handeln kommen.',
    problems: ['Viele parallele Fächer', 'Unklare Karriereziele', 'Schieben von Gruppenarbeiten', 'Zahlenstress', 'Prüfungsdruck', 'Vergleich mit anderen'],
    modules: ['Wochenstruktur für mehrere Fächer', 'Entscheidungen mit Kriterien treffen', 'Lernfortschritt sichtbar machen', 'Präsentationen vorbereiten', 'Karriereoptionen sortieren'],
    tone: 'pragmatisch, fokussiert, zielklar, ruhig'
  },
  Informatik: {
    headline: 'Vom Problem zur eleganten Lösung. Ohne dich in Details zu verlieren.',
    problems: ['Prokrastination bei grossen Projekten', 'Zu viele offene technische Fragen', 'Perfektionismus', 'Debugging Frust', 'Unsicherheit rund um KI', 'Fehlende Projektstruktur', 'Isoliertes Arbeiten'],
    modules: ['Projekte in Meilensteine teilen', 'Debugging Routinen', 'Deep Work ohne Überforderung', 'KI sinnvoll nutzen', 'Portfolio und Fortschritt sichtbar machen'],
    tone: 'logisch, ruhig, lösungsorientiert, tiefgehend'
  },
  Ingenieurwesen: {
    headline: 'Komplexe Aufgaben werden lösbar, wenn der nächste Schritt klar ist.',
    problems: ['Hohe Stoffdichte', 'Mathematische Blockaden', 'Projektstress', 'Zu wenig Überblick', 'Perfektionismus bei Lösungen', 'Prüfungsdruck'],
    modules: ['Komplexität zerlegen', 'Rechenroutinen aufbauen', 'Projektplanung', 'Prüfungssimulation', 'Fehleranalyse ohne Selbstabwertung'],
    tone: 'sachlich, stabil, präzise, umsetzungsorientiert'
  },
  Lehramt: {
    headline: 'Zwischen Studium, Praxis und Verantwortung wieder Orientierung finden.',
    problems: ['Viele Anforderungen', 'Praxisdruck', 'Unsicherheit in der Rolle', 'Prüfungen und Unterrichtsplanung', 'Hohe Erwartungen', 'Emotionale Belastung'],
    modules: ['Rollenklärung', 'Semesterstruktur', 'Prüfungsvorbereitung', 'Selbstführung im Praxissemester', 'Reflexion ohne Überforderung'],
    tone: 'ermutigend, klar, warm, praxisnah'
  },
  'Soziale Arbeit': {
    headline: 'Struktur behalten, auch wenn die Themen menschlich komplex sind.',
    problems: ['Emotionale Belastung', 'Praxis und Theorie verbinden', 'Unsicherheit bei Fällen', 'Selbstzweifel', 'Abgrenzung', 'Viele offene Aufgaben'],
    modules: ['Fallreflexion strukturieren', 'Abgrenzung lernen', 'Wochenplanung', 'Selbstzweifel prüfen', 'Praxislernen sichtbar machen'],
    tone: 'wertschätzend, klar, ruhig, menschlich'
  },
  Geisteswissenschaften: {
    headline: 'Aus vielen Gedanken wird eine tragfähige Struktur.',
    problems: ['Zu viele Texte', 'Unklare Schreibstruktur', 'Perfektionismus', 'Themen verlieren sich', 'Motivationslöcher', 'Unsicherheit über Perspektiven'],
    modules: ['Lesen mit System', 'Schreibstruktur entwickeln', 'Themen eingrenzen', 'Argumentation sichtbar machen', 'Karriereoptionen sortieren'],
    tone: 'reflektiert, sprachlich klar, offen, strukturierend'
  },
  Naturwissenschaften: {
    headline: 'Aus Stoff, Formeln und Labor wird ein lernbares System.',
    problems: ['Dichte Inhalte', 'Laborberichte', 'Prüfungsdruck', 'Fehlende Wiederholung', 'Unklare Prioritäten', 'Vergleich mit anderen'],
    modules: ['Stoff clustern', 'Wiederholungssysteme', 'Laborberichte strukturieren', 'Prüfungsphasen planen', 'Fortschritt sichtbar machen'],
    tone: 'analytisch, ruhig, genau, entlastend'
  },
  Luftfahrt: {
    headline: 'Klarheit, Struktur und Reflexion für anspruchsvolle Ausbildungssituationen.',
    problems: ['Hohe Standards', 'Checkdruck', 'Theorie und Praxis parallel', 'Fehleranalyse', 'Selbstzweifel nach Feedback', 'Mentale Belastung'],
    modules: ['Debriefing Journal', 'Fehler in Lernschritte übersetzen', 'Prüfungsphasen planen', 'Stressregulation', 'Routinen und Checklisten'],
    tone: 'präzise, ruhig, sicherheitsbewusst, professionell'
  },
  Anderes: {
    headline: 'Klarheit für dein Studium, auch wenn es nicht in eine Schublade passt.',
    problems: ['Unklare Prioritäten', 'Prokrastination', 'Prüfungsdruck', 'Entscheidungsdruck', 'Selbstzweifel', 'Fehlende Struktur'],
    modules: ['KLAR Start', 'Prokrastination verstehen', 'Reflexionssystem aufbauen', 'Prüfungsphase planen', 'Entscheidungen strukturieren'],
    tone: 'klar, individuell, ruhig, stärkend'
  }
};

const programs = [
  ['KLAR Start', 'Für Studierende, die wieder Ordnung in ihr Studium bringen wollen.', ['Situationsanalyse', 'Prioritätenmatrix', 'Wochenstruktur', 'Erste Routinen', 'Reflexionssystem einrichten']],
  ['KLAR Gegen Prokrastination', 'Für Vermeidung, inneren Druck und blockierte Umsetzung.', ['Prokrastinationsmuster erkennen', 'Emotionale Blockaden analysieren', 'Aufgaben entwirren', 'Realistische Lernpläne', 'KI Reflexion']],
  ['KLAR Prüfungsphase', 'Für strukturierte und ruhige Prüfungsvorbereitung.', ['Stoffanalyse', 'Lernphasen planen', 'Wiederholungssystem', 'Prüfungssimulation', 'Stressregulation']],
  ['KLAR Entscheidung', 'Für Studienzweifel, Masterwahl, Karrierefragen oder Richtungswechsel.', ['Entscheidungsdruck verstehen', 'Optionen sortieren', 'Werte klären', 'Konsequenzen analysieren', 'Nächsten Schritt definieren']],
  ['KLAR Reflexion', 'Für Studierende, die Entwicklung sichtbar machen wollen.', ['Reflexionsjournal', 'KI Kategorien', 'Monatsrückblicke', 'Jahresrückblick', 'Erfolge und Komplimente sammeln']]
];

const faq = [
  ['Ist das Therapie?', 'Nein. KLAR Study ist Coaching, E Learning und Selbststrukturierung. Es ersetzt keine Psychotherapie, medizinische Behandlung oder Diagnostik.'],
  ['Für wen ist KLAR Study geeignet?', 'Für Studierende, die viel denken, viel wahrnehmen und konkrete Struktur brauchen, um wieder handlungsfähig zu werden.'],
  ['Muss ich mein Studienfach genau kennen?', 'Nein. Du kannst auch mit einem allgemeinen Bereich starten. Die Inhalte können später angepasst werden.'],
  ['Was passiert mit meinen Daten?', 'In dieser Demo werden keine Daten an eine Datenbank gesendet. Für eine echte App sollte transparent geregelt werden, wo Daten gespeichert werden und wer Zugriff hat.'],
  ['Kann ich nur das E Learning buchen?', 'Ja. KLAR Study kann als reines E Learning, als Coaching oder als Kombination genutzt werden.'],
  ['Gibt es ein Angebot speziell gegen Prokrastination?', 'Ja. KLAR Gegen Prokrastination verbindet Aufgabenklärung, emotionale Blockaden, Mini Schritte und Reflexion.'],
  ['Wie funktioniert die KI Analyse?', 'Einträge werden nach Kategorien, Mustern und nächsten Schritten sortiert. Die KI ersetzt keine eigene Entscheidung, sie unterstützt die Reflexion.'],
  ['Kann ich meine Excel Liste verwenden?', 'Ja. Das Reflexionssystem ist so gedacht, dass Excel oder Google Sheets eingebunden werden können.']
];

function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/studienfeld" element={<FieldPage />} />
          <Route path="/programme" element={<Programs />} />
          <Route path="/reflexion" element={<Reflection />} />
          <Route path="/prokrastination" element={<Procrastination />} />
          <Route path="/coaching" element={<Coaching />} />
          <Route path="/ueber-lara" element={<About />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/klarheits-check" element={<ClarityCheck />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}

function Layout({ children }) {
  const [open, setOpen] = useState(false);
  const links = [
    ['/', 'Home'], ['/studienfeld', 'Studienfeld'], ['/programme', 'Programme'], ['/reflexion', 'Reflexionssystem'], ['/prokrastination', 'Prokrastination'], ['/coaching', 'Coaching'], ['/ueber-lara', 'Über Lara'], ['/faq', 'FAQ']
  ];
  return <>
    <header className="header">
      <Link to="/" className="logo"><span>KLAR</span> Study <small>by Lara Jehn</small></Link>
      <nav className={open ? 'nav open' : 'nav'}>
        {links.map(([to, label]) => <NavLink key={to} to={to} onClick={() => setOpen(false)}>{label}</NavLink>)}
        <Link className="primary small" to="/klarheits-check" onClick={() => setOpen(false)}>Klarheits Check starten</Link>
      </nav>
      <button className="menu" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
    </header>
    <main>{children}</main>
    <footer className="footer">
      <div><strong>KLAR Study by Lara Jehn</strong><p>Coaching, E Learning und Reflexion für mehr Klarheit im Studium.</p></div>
      <p className="note">Hinweis: KLAR Study ersetzt keine Therapie, medizinische Behandlung oder psychologische Diagnostik.</p>
    </footer>
  </>;
}

function Reveal({ children, className = '' }) {
  return <motion.div className={className} initial={{ opacity: 0, y: 22 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: .55 }}>{children}</motion.div>;
}

function Home() {
  return <>
    <section className="hero">
      <div className="heroText">
        <p className="eyebrow">KLAR Study</p>
        <h1>Dein Studium braucht nicht mehr Druck. Es braucht mehr Klarheit.</h1>
        <p className="lead">KLAR Study hilft Studierenden, Überforderung, Prokrastination und Entscheidungsdruck strukturiert zu verstehen und daraus konkrete nächste Schritte zu machen. Mit E Learning, KI unterstützter Reflexion, persönlichem Coaching und einem Lernsystem passend zu deinem Studienfeld.</p>
        <div className="actions"><Link className="primary" to="/studienfeld">Studienfeld wählen</Link><Link className="secondary" to="/klarheits-check">Kostenlosen Klarheits Check starten</Link></div>
      </div>
      <DashboardMock />
    </section>
    <section className="section">
      <Reveal><p className="eyebrow">Vielleicht kennst du das</p><h2>Du bist nicht faul. Vielleicht ist gerade einfach zu viel offen.</h2></Reveal>
      <div className="grid five">
        {['Du willst lernen, aber du fängst nicht an.', 'Du hast viele Aufgaben, aber keine klare Reihenfolge.', 'Du denkst ständig ans Studium, kommst aber nicht ins Handeln.', 'Du machst viel und hast trotzdem das Gefühl, nicht das Richtige zu tun.', 'Du schiebst Entscheidungen auf, bis sie noch mehr Druck erzeugen.'].map((t, i) => <Reveal className="card problem" key={t}><span>{String(i + 1).padStart(2, '0')}</span><p>{t}</p></Reveal>)}
      </div>
    </section>
    <section className="section tinted">
      <Reveal><p className="eyebrow">Die Lösung</p><h2>Drei Bausteine, die zusammen Ordnung schaffen.</h2></Reveal>
      <div className="grid three">
        <Feature icon={<BookOpen />} title="E Learning" text="Strukturierte Module für typische Studienprobleme: Planung, Prüfungsphase, Prokrastination, Selbstzweifel und Entscheidungen." link="/programme" />
        <Feature icon={<Brain />} title="Reflexionssystem" text="Ein digitales Journal, das Gedanken, Learnings, Erfolge, Blockaden und nächste Schritte sichtbar macht." link="/reflexion" />
        <Feature icon={<MessageCircle />} title="Coaching" text="Persönliche Unterstützung, wenn du nicht nur Tipps brauchst, sondern individuelle Klarheit und Struktur." link="/coaching" />
      </div>
    </section>
    <Social />
  </>;
}

function DashboardMock() {
  return <Reveal className="mock">
    <div className="mockTop"><span></span><span></span><span></span></div>
    <div className="mockHeader"><h3>Dein KLAR Dashboard</h3><Sparkles /></div>
    <div className="mockGrid">
      {['Reflexion heute', 'Nächster kleiner Schritt', 'Learnings des Monats', 'Deine Erfolge', 'Komplimente', 'Heute vor einem Jahr'].map((t, i) => <div className="mini" key={t}><b>{t}</b><p>{['Was war heute wesentlich?', '25 Minuten Skript Kapitel 3', 'Prioritäten werden klarer', '3 sichtbare Fortschritte', 'Du erklärst ruhig und klar', 'Damals begann deine neue Struktur'][i]}</p></div>)}
    </div>
    <div className="flow"><span>Selbstzweifel</span><span>Prioritäten</span><span>Lernblock</span><span>Nächste Aktion</span></div>
  </Reveal>;
}

function Feature({ icon, title, text, link }) {
  return <Reveal className="card feature"><div className="icon">{icon}</div><h3>{title}</h3><p>{text}</p><Link to={link}>Mehr erfahren</Link></Reveal>;
}

function FieldPage() {
  const [field, setField] = useState('Psychologie');
  const [problem, setProblem] = useState('Prokrastination');
  const data = fields[field];
  const problemList = ['Prokrastination', 'Überforderung', 'Prüfungsangst', 'Entscheidungsdruck', 'Fehlende Struktur', 'Selbstzweifel', 'Motivationsverlust', 'Zweifel am Studienwechsel'];
  return <section className="section page">
    <Reveal><p className="eyebrow">Personalisierung</p><h1>Wähle dein Studienfeld und dein aktuelles Hauptproblem.</h1><p className="lead narrow">Die Sprache, Beispiele, Reflexionsfragen und Empfehlungen passen sich sofort an.</p></Reveal>
    <div className="selectorGrid">
      <div className="panel"><h3>Studienfeld</h3><div className="chips">{Object.keys(fields).map(f => <button className={field === f ? 'chip active' : 'chip'} onClick={() => setField(f)} key={f}>{f}</button>)}</div></div>
      <div className="panel"><h3>Hauptproblem</h3><div className="chips">{problemList.map(p => <button className={problem === p ? 'chip active' : 'chip'} onClick={() => setProblem(p)} key={p}>{p}</button>)}</div></div>
    </div>
    <div className="resultCard">
      <div><p className="eyebrow">Dein Profil</p><h2>{data.headline}</h2><p>Aktueller Fokus: <strong>{problem}</strong>. Sprachton: {data.tone}.</p></div>
      <div className="twoCols">
        <List title="Typische Themen" items={data.problems} />
        <List title="Empfohlene Module" items={data.modules} />
      </div>
      <div className="reflectionBox"><Lightbulb /><p><strong>Reflexionsfrage:</strong> Welche Aufgabe erzeugt gerade am meisten Druck, weil sie innerlich noch nicht klar genug definiert ist?</p></div>
    </div>
  </section>;
}

function Programs() {
  return <section className="section page"><Reveal><p className="eyebrow">Programme</p><h1>Fünf Wege zurück in Klarheit und Umsetzung.</h1></Reveal><div className="grid cards">{programs.map(([title, text, items]) => <Reveal className="card program" key={title}><GraduationCap /><h3>{title}</h3><p>{text}</p><ul>{items.map(i => <li key={i}><CheckCircle />{i}</li>)}</ul><Link className="secondary full" to="/klarheits-check">Passung prüfen</Link></Reveal>)}</div></section>;
}

function Reflection() {
  const cols = ['Datum', 'Situation', 'Learning', 'Warum wichtig?', 'Kategorie', 'Gefühl', 'Nächster Schritt', 'Gegenbeweis', 'Erfolg', 'Kompliment', 'Studienbezug', 'KI Zusammenfassung'];
  return <section className="section page"><Reveal><p className="eyebrow">Reflexionssystem</p><h1>Deine Gedanken werden zu einem System.</h1><p className="lead narrow">Du schreibst Gedanken, Learnings, Erfolge und Blockaden auf. Die KI hilft dir, Muster, Kategorien und nächste Schritte zu erkennen.</p></Reveal>
    <div className="dashboardWide">
      {['Learning des Tages', 'Erfolg', 'Kompliment', 'Blockade', 'Nächster Schritt', 'Heute vor einem Jahr', 'Learnings des Monats'].map((c, i) => <div className="card stat" key={c}><b>{c}</b><p>{['Ich lerne besser mit klaren Endpunkten.', '2 Stunden fokussiert gelernt.', 'Du hast ruhig erklärt.', 'Zu grosse Aufgabe.', 'Nur Einleitung strukturieren.', 'Erster Wochenplan.', 'Mehr kleine Schritte, weniger Druck.'][i]}</p></div>)}
    </div>
    <div className="visuals"><Chart title="Stimmungskurve" /><Chart title="Lernmuster" /><CategoryCloud /></div>
    <div className="tableBox"><h2>Excel und Learning Journal Konzept</h2><div className="tableScroll"><table><thead><tr>{cols.map(c => <th key={c}>{c}</th>)}</tr></thead><tbody><tr>{cols.map((c, i) => <td key={c}>{i === 0 ? '12.06.2026' : i === 4 ? 'Prioritäten' : i === 6 ? '25 Minuten Start' : 'Beispiel'}</td>)}</tr></tbody></table></div><button className="primary" onClick={() => alert('KI Analyse Demo: Muster erkannt. Du vermeidest Aufgaben häufiger, wenn der erste Schritt nicht sichtbar ist. Empfohlene Aktion: Aufgabe in eine 5 Minuten Handlung übersetzen.')}>KI Analyse simulieren</button></div>
    <Smartboard />
  </section>;
}

function Chart({ title }) {
  return <div className="card chart"><h3>{title}</h3><div className="bars"><span style={{height:'35%'}}></span><span style={{height:'65%'}}></span><span style={{height:'45%'}}></span><span style={{height:'80%'}}></span><span style={{height:'55%'}}></span></div></div>;
}

function CategoryCloud() {
  return <div className="card"><h3>Kategorien</h3><div className="chips"><span className="chip">Learning</span><span className="chip">Emotion</span><span className="chip">Prüfung</span><span className="chip">Selbstzweifel</span><span className="chip">Fortschritt</span><span className="chip">Prioritäten</span><span className="chip">Entscheidung</span><span className="chip">Nächster Schritt</span></div></div>;
}

function Smartboard() {
  const [on, setOn] = useState(false);
  return <div className={on ? 'smartboard active' : 'smartboard'}><div className="smartHead"><h2>Für Coaching, Workshops und Seminare</h2><button className="secondary" onClick={() => setOn(!on)}>Smartboard Ansicht {on ? 'aus' : 'ein'}</button></div><div className="grid five"><div>Top 5 Learnings</div><div>Wiederkehrende Muster</div><div>Grösster Fortschritt</div><div>Bedeutendstes Kompliment</div><div>Nächster Fokus</div></div></div>;
}

function Procrastination() {
  const [type, setType] = useState(null);
  const questions = ['Ich weiss oft nicht, womit ich anfangen soll.', 'Ich schiebe auf, weil ich es perfekt machen will.', 'Ich vermeide Aufgaben, wenn sie emotional unangenehm sind.'];
  return <section className="section page"><Reveal><p className="eyebrow">KLAR Gegen Prokrastination</p><h1>Warte nicht auf Motivation. Verstehe, was dich blockiert.</h1><p className="lead narrow">Der nächste Schritt wird so klein, klar und machbar, dass du ihn wirklich gehst.</p></Reveal>
    <div className="grid cards">{['Warum du prokrastinierst', 'Aufgaben entwirren', 'Lernplan ohne Selbstbetrug', 'Umsetzung', 'KI Reflexion'].map((m, i) => <div className="card"><Clock /><h3>Modul {i + 1}: {m}</h3><p>{['Prokrastination als Schutzmechanismus, Angst vor Fehlern, unklare Aufgaben und Überforderung.', 'Aus Ich muss lernen wird eine klare Frage nach Was, Wofür, Bis wann und Womit zuerst.', 'Realistische Planung mit Energie, Puffern, Tageszielen und Wochenrückblick.', '5 Minuten Start, sichtbarer Fortschritt, Accountability, Belohnung und Rückfallplan.', 'Die KI erkennt Zeiten, Aufgaben, Gedanken und kleine Schritte, die wirklich helfen.'][i]}</p></div>)}</div>
    <div className="checkBox"><h2>Interaktiver Prokrastinations Check</h2>{questions.map((q, i) => <label key={q}><input type="radio" name="p" onChange={() => setType(i)} /> {q}</label>)}{type !== null && <div className="resultCard smallResult"><h3>Dein Ergebnis</h3><p><strong>Prokrastinationstyp:</strong> {['Unklarheits Vermeidung', 'Perfektionismus Vermeidung', 'Emotionale Vermeidung'][type]}</p><p><strong>Erster kleiner Schritt:</strong> Öffne nur das Dokument und formuliere die nächste konkrete Handlung in einem Satz.</p><Link className="primary" to="/klarheits-check">Empfehlung erhalten</Link></div>}</div>
  </section>;
}

function Coaching() {
  return <section className="section page"><Reveal><p className="eyebrow">Coaching</p><h1>Wenn du nicht mehr Tipps brauchst, sondern jemanden, der mit dir Ordnung schafft.</h1><p className="lead narrow">Wir betrachten deine konkrete Situation strukturiert, nicht abstrakt und nicht bewertend. Wir analysieren, was dich blockiert, welche Muster sich wiederholen und welcher nächste Schritt realistisch ist.</p></Reveal><div className="grid cards">{['Prokrastination', 'Überforderung', 'Entscheidungen', 'Prüfungsvorbereitung', 'Selbstzweifel', 'Studienplanung', 'Routinen', 'Prioritäten', 'Selbstführung', 'Druck'].map(t => <div className="card topic" key={t}>{t}</div>)}</div><div className="resultCard"><h2>Formate</h2><p>Einzelcoaching, Paket mit 3 Sitzungen, Paket mit 6 Sitzungen, E Learning plus Coaching, Gruppenworkshop und Smartboard Reflexionssession.</p><Link className="primary" to="/klarheits-check">Klarheitsgespräch vorbereiten</Link></div></section>;
}

function About() {
  return <section className="section page about"><Reveal><p className="eyebrow">Über Lara</p><h1>Ich verbinde Struktur, Tiefe und Umsetzung.</h1><p className="lead">Ich arbeite mit Studierenden, die viel denken, viel wahrnehmen und oft mehr Potenzial haben, als sie im Alltag gerade ausdrücken können. Viele scheitern nicht daran, dass sie zu wenig wollen. Sie scheitern daran, dass zu viele Dinge gleichzeitig offen sind. Deshalb beginnt meine Arbeit nicht mit mehr Druck. Sie beginnt mit Klarheit.</p></Reveal><div className="klarMethod"><div><b>K</b><span>Klärung</span></div><div><b>L</b><span>Leitlinie</span></div><div><b>A</b><span>Aktion</span></div><div><b>R</b><span>Reflexion</span></div></div></section>;
}

function FAQ() { return <section className="section page"><Reveal><p className="eyebrow">FAQ</p><h1>Häufige Fragen</h1></Reveal><div className="faq">{faq.map(([q,a]) => <details className="card" key={q}><summary>{q}</summary><p>{a}</p></details>)}</div></section>; }

function ClarityCheck() {
  const [done, setDone] = useState(false);
  const [values, setValues] = useState({ field: 'Psychologie', semester: '', problem: 'Prokrastination', exam: '', behavior: '', support: 'E Learning plus Coaching' });
  const mainBlock = values.problem === 'Prokrastination' ? 'Der erste Schritt ist vermutlich zu unklar oder emotional zu gross.' : 'Es sind vermutlich zu viele offene Ebenen gleichzeitig aktiv.';
  return <section className="section page"><Reveal><p className="eyebrow">Klarheits Check</p><h1>Erste Einschätzung für deine Studiensituation.</h1></Reveal>{!done ? <form className="form" onSubmit={e => { e.preventDefault(); setDone(true); }}>
    <Select label="Studienfeld" value={values.field} onChange={v => setValues({...values, field: v})} options={Object.keys(fields)} />
    <Input label="Semester" value={values.semester} onChange={v => setValues({...values, semester: v})} />
    <Select label="Grösstes aktuelles Problem" value={values.problem} onChange={v => setValues({...values, problem: v})} options={['Prokrastination', 'Überforderung', 'Prüfungsangst', 'Entscheidungsdruck', 'Fehlende Struktur', 'Selbstzweifel']} />
    <Input label="Aktuelle Prüfung oder Entscheidung" value={values.exam} onChange={v => setValues({...values, exam: v})} />
    <Input label="Wie zeigt sich deine Prokrastination oder Blockade?" value={values.behavior} onChange={v => setValues({...values, behavior: v})} />
    <Select label="Gewünschte Unterstützung" value={values.support} onChange={v => setValues({...values, support: v})} options={['Nur E Learning', 'Nur Coaching', 'E Learning plus Coaching', 'Reflexionssystem']} />
    <button className="primary">Ergebnis anzeigen</button>
  </form> : <div className="resultCard"><h2>Deine erste Einschätzung</h2><p><strong>Studienfeld:</strong> {values.field}</p><p><strong>Wahrscheinlicher Hauptblock:</strong> {mainBlock}</p><p><strong>Empfohlenes Programm:</strong> {values.problem === 'Prokrastination' ? 'KLAR Gegen Prokrastination' : 'KLAR Start'}</p><p><strong>Nächster kleiner Schritt:</strong> Schreibe eine Aufgabe so konkret auf, dass sie in 5 Minuten begonnen werden kann.</p><Link className="primary" to="/coaching">Gespräch vorbereiten</Link></div>}</section>;
}

function Select({ label, value, onChange, options }) { return <label><span>{label}</span><select value={value} onChange={e => onChange(e.target.value)}>{options.map(o => <option key={o}>{o}</option>)}</select></label>; }
function Input({ label, value, onChange }) { return <label><span>{label}</span><input value={value} onChange={e => onChange(e.target.value)} placeholder="Deine Antwort" /></label>; }
function List({ title, items }) { return <div><h3>{title}</h3><ul className="clean">{items.map(i => <li key={i}><CheckCircle />{i}</li>)}</ul></div>; }

function Social() { return <section className="section"><Reveal><p className="eyebrow">Content Ideen</p><h2>Social Media und Werbevideos</h2></Reveal><div className="grid three"><div className="card"><Monitor /><h3>Video 1: Prokrastination</h3><p>Viele Tabs, mentaler Druck, KLAR Dashboard sortiert Aufgaben, ein kleiner nächster Schritt entsteht.</p></div><div className="card"><BarChart3 /><h3>Video 2: Reflexionssystem</h3><p>Abendreflexion, KI Kategorien, Monatsrückblick und Smartboard für sichtbare Entwicklung.</p></div><div className="card"><Layers /><h3>Fotostil</h3><p>Helle Räume, ruhige Lernumgebung, Laptop, Notebook, Tee oder Kaffee, weiches Tageslicht und blau graue Palette.</p></div></div></section>; }

createRoot(document.getElementById('root')).render(<App />);
