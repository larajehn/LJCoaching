# KLAR Study by Lara Jehn

Deutsche Website und Web App für KLAR Study.

## Lokal starten

1. Node.js installieren
2. Projektordner öffnen
3. `npm install` ausführen
4. `npm run dev` ausführen
5. Lokalen Link öffnen

## Online mit GitHub Pages veröffentlichen

1. Neues GitHub Repository erstellen
2. Alle Dateien hochladen
3. Unter Settings > Pages als Quelle GitHub Actions auswählen
4. Unter Actions den Workflow abwarten
5. Die veröffentlichte Seite öffnen
